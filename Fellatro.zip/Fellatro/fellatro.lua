--- STEAMODDED HEADER
--- MOD_NAME: Fellatro
--- MOD_ID: fellatro
--- MOD_AUTHOR: [Dr. Hierarchy]
--- MOD_DESCRIPTION: its fellatro time
--- BADGE_COLOR: 631DC4
--- DEPENDENCIES: [Steamodded, Talisman, Cryptid]
----------------------------------------------
------------MOD CODE -------------------------

function SMODS.INIT.TexturePackTemplate()
    sendDebugMessage("Launching Fellatro!")

    local tpt_mod = SMODS.findModByID("fellatro")
    local sprite_vouchers = SMODS.Sprite:new("Voucher", tpt_mod.path, "Vouchers.png", 71, 95, "asset_atli")
    local sprite_deck1 = SMODS.Sprite:new("cards_1", tpt_mod.path, "8BitDeck.png", 71, 95, "asset_atli")
    local sprite_deck2 = SMODS.Sprite:new("cards_2", tpt_mod.path, "8BitDeck_opt2.png", 71, 95, "asset_atli")
    local sprite_chips = SMODS.Sprite:new("chips", tpt_mod.path, "chips.png", 29, 29, "asset_atli")
    local sprite_enhancers = SMODS.Sprite:new("centers", tpt_mod.path, "Enhancers.png", 71, 95, "asset_atli")
    local sprite_gamepad = SMODS.Sprite:new("gamepad_ui", tpt_mod.path, "gamepad_ui.png", 32, 32, "asset_atli")
    local sprite_icons = SMODS.Sprite:new("icons", tpt_mod.path, "icons.png", 66, 66, "asset_atli")
    local sprite_localthunk = SMODS.Sprite:new("localthunk_logo", tpt_mod.path, "localthunk-logo.png", 1390, 560, "asset_images")
    local sprite_playstack = SMODS.Sprite:new("playstack_logo", tpt_mod.path, "playstack-logo.png", 1417, 1417, "asset_images")
    local sprite_shop = SMODS.Sprite:new("shop_sign", tpt_mod.path, "ShopSignAnimation.png", 113, 57, "animation_atli", 4)
    local sprite_stickers = SMODS.Sprite:new("stickers", tpt_mod.path, "stickers.png", 71, 95, "asset_atli")
    local sprite_tags = SMODS.Sprite:new("tags", tpt_mod.path, "tags.png", 34, 34, "asset_atli")
    local sprite_tarots = SMODS.Sprite:new("Tarot", tpt_mod.path, "Tarots.png", 71, 95, "asset_atli")
    local sprite_ui1 = SMODS.Sprite:new("ui_1", tpt_mod.path, "ui_assets.png", 18, 18, "asset_atli")
    local sprite_ui2 = SMODS.Sprite:new("ui_2", tpt_mod.path, "ui_assets_opt2.png", 18, 18, "asset_atli")
    local sprite_jkr = SMODS.Sprite:new("Joker", tpt_mod.path, "Jokers.png", 71, 95, "asset_atli")
    local sprite_boost = SMODS.Sprite:new("Booster", tpt_mod.path, "boosters.png", 71, 95, "asset_atli")
    local sprite_blind = SMODS.Sprite:new("blind_chips", tpt_mod.path, "BlindChips.png", 34, 34, "animation_atli", 21)
    local sprite_collab_au1 = SMODS.Sprite:new("collab_AU_1", tpt_mod.path, "collabs/collab_AU_1.png", 71, 95, "asset_atli")
    local sprite_collab_au2 = SMODS.Sprite:new("collab_AU_2", tpt_mod.path, "collabs/collab_AU_2.png", 71, 95, "asset_atli")
    local sprite_collab_tw1 = SMODS.Sprite:new("collab_TW_1", tpt_mod.path, "collabs/collab_TW_1.png", 71, 95, "asset_atli")
    local sprite_collab_tw2 = SMODS.Sprite:new("collab_TW_2", tpt_mod.path, "collabs/collab_TW_2.png", 71, 95, "asset_atli")
    local sprite_collab_vs1 = SMODS.Sprite:new("collab_VS_1", tpt_mod.path, "collabs/collab_VS_1.png", 71, 95, "asset_atli")
    local sprite_collab_vs2 = SMODS.Sprite:new("collab_VS_2", tpt_mod.path, "collabs/collab_VS_2.png", 71, 95, "asset_atli")
    local sprite_collab_dtd1 = SMODS.Sprite:new("collab_DTD_1", tpt_mod.path, "collabs/collab_DTD_1.png", 71, 95, "asset_atli")
    local sprite_collab_dtd2 = SMODS.Sprite:new("collab_DTD_2", tpt_mod.path, "collabs/collab_DTD_2.png", 71, 95, "asset_atli")
    local sprite_collab_cyp1 = SMODS.Sprite:new("collab_CYP_1", tpt_mod.path, "collabs/collab_CYP_1.png", 71, 95, "asset_atli")
    local sprite_collab_cyp2 = SMODS.Sprite:new("collab_CYP_2", tpt_mod.path, "collabs/collab_CYP_2.png", 71, 95, "asset_atli")
    local sprite_collab_sts1 = SMODS.Sprite:new("collab_STS_1", tpt_mod.path, "collabs/collab_STS_1.png", 71, 95, "asset_atli")
    local sprite_collab_sts2 = SMODS.Sprite:new("collab_STS_2", tpt_mod.path, "collabs/collab_STS_2.png", 71, 95, "asset_atli")
    local sprite_collab_tboi1 = SMODS.Sprite:new("collab_TBoI_1", tpt_mod.path, "collabs/collab_TBoI_1.png", 71, 95, "asset_atli")
    local sprite_collab_tboi2 = SMODS.Sprite:new("collab_TBoI_2", tpt_mod.path, "collabs/collab_TBoI_2.png", 71, 95, "asset_atli")
    local sprite_collab_sv1 = SMODS.Sprite:new("collab_SV_1", tpt_mod.path, "collabs/collab_SV_1.png", 71, 95, "asset_atli")
    local sprite_collab_sv2 = SMODS.Sprite:new("collab_SV_2", tpt_mod.path, "collabs/collab_SV_2.png", 71, 95, "asset_atli")

    sprite_vouchers:register()
    sprite_deck1:register()
    sprite_deck2:register()
    sprite_chips:register()
    sprite_enhancers:register()
    sprite_gamepad:register()
    sprite_icons:register()
    sprite_localthunk:register()
    sprite_playstack:register()
    sprite_shop:register()
    sprite_stickers:register()
    sprite_tags:register()
    sprite_tarots:register()
    sprite_ui1:register()
    sprite_ui2:register()
    sprite_jkr:register()
    sprite_boost:register()
    sprite_blind:register()
    sprite_collab_au1:register()
    sprite_collab_au2:register()
    sprite_collab_tw1:register()
    sprite_collab_tw2:register()
    sprite_collab_vs1:register()
    sprite_collab_vs2:register()
    sprite_collab_dtd1:register()
    sprite_collab_dtd2:register()
    sprite_collab_cyp1:register()
    sprite_collab_cyp2:register()
    sprite_collab_sts1:register()
    sprite_collab_sts2:register()
    sprite_collab_tboi1:register()
    sprite_collab_tboi2:register()
    sprite_collab_sv1:register()
    sprite_collab_sv2:register()

-- thx yahiamice :3
SMODS.Sound({key = "red_401", path = "red_401.ogg",})
SMODS.Sound({key = "red_402", path = "red_402.ogg",})

SMODS.Shader({ key = "red40", path = "red40.fs" })

    SMODS.Edition {
    key = "red_40",
    loc_txt = {
        name = "Red 40",
        label = "Red 40",
        text = {
            "{C:mult}+40{} Mult",
            "{C:green}1 in 6{} chance to be",
            "{C:red}destroyed{} at end of round",
            "{C:inactive}gloopy"
        }
    },
    config = { mult = 40 },
    shader = 'red40',
    discovered = true,
    unlocked = true,
    weight = 0.4, -- Rarity weight (lower = rarer)
    extra_cost = 4, -- Additional cost when buying from shop
    get_weight = function(self)
        return G.GAME.edition_rate * self.weight
    end,
    sound = {
        sound = 'red_401',
        per = 1,
        vol = 0.9
    },
    loc_vars = function(self, info_queue, center)
        return { vars = {self.config.mult}}
    end,
    calculate = function(self, card, context)
        if context.pre_joker or (context.main_scoring and context.cardarea == G.play) then
            return {
                mult = card.edition.mult
            }
        end
    end
    }
-- Hook into end of round to handle destruction chance
local end_round_ref = end_round
function end_round()
    -- Check all jokers for red_40 edition
    local jokers_to_destroy = {}
    local survival_messages = {}

    if G.jokers then
        for i = 1, #G.jokers.cards do
            local card = G.jokers.cards[i]
            if card.edition and card.edition.red_40 then
                -- Roll for destruction (1 in 6 chance)
                local roll = pseudorandom('red_40_destruction') * 6
                if roll < 1 then
                    -- Mark for destruction
                    table.insert(jokers_to_destroy, card)
                else
                    -- Survived - add to survival messages
                    table.insert(survival_messages, card)
                end
            end
        end
    end

    -- Show survival messages first
    if #survival_messages > 0 then
        for _, card in ipairs(survival_messages) do
            card_eval_status_text(card, 'extra', nil, nil, nil, {
                message = "Safe!",
                colour = G.C.ORANGE,
                delay = 0.7
            })
        end
    end

    -- Destroy marked jokers with messages
    if #jokers_to_destroy > 0 then
        for i, card in ipairs(jokers_to_destroy) do
            -- Show destruction message
            card_eval_status_text(card, 'extra', nil, nil, nil, {
                message = "FDA Regulated!",
                colour = G.C.RED,
                delay = 0.7 + (i * 0.3)
            })

            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.8 + (i * 0.3),
                func = function()
                    play_sound('red_402', 1, 0.9)
                    return true
                end
                }))

            -- Actually destroy the card after a delay
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 1.0 + (i * 0.3),
                func = function()
                    card:start_dissolve()
                    return true
                end
            }))
        end
    end

    -- Call original end_round function
    end_round_ref()
end

-- Add the edition to the pool
local get_edition_ref = get_edition
function get_edition(key)
    if key == 'red_40' then
        return {
            red_40 = true,
            mult = 40
        }
    end
    return get_edition_ref(key)
end

-- Make sure the edition can appear in shops and as rewards
local create_card_ref = create_card
function create_card(_type, area, legendary, _rarity, skip_materialize, soulable, forced_key, key_append)
    local card = create_card_ref(_type, area, legendary, _rarity, skip_materialize, soulable, forced_key, key_append)

    -- Small chance for jokers to spawn with red_40 edition
    if _type == 'Joker' and card and pseudorandom('red_40_spawn') < 0.1 then
        card:set_edition({red_40 = true}, true)
    end

    return card
end


    SMODS.Atlas {
    key = "the_cancer_atlas",
    path = "Tarots.png",
    px = 71,
    py = 95
}

    SMODS.Consumable {
    key = "the_goop",
    set = "Tarot",
    pos = {x = 6, y = 5},
    loc_txt = {
        name = "The Goop",
        text = {
            "{C:green}1 in 4{} chance to add",
            "{C:red}Red 40{} to a",
            "random {C:attention}Joker{}"
        }
    },
    -- Card properties
    discovered = false,
    unlocked = true,
    cost = 3,
    -- Use function when card is played
    use = function(self, card, area, copier)
        -- Roll for success (1 in 4 chance)
        if pseudorandom('goop_tarot') < 0.25 then
            -- Find all jokers
            local jokers = {}
            for i = 1, #G.jokers.cards do
                local joker = G.jokers.cards[i]
                -- Only target jokers without an edition
                if not joker.edition then
                    table.insert(jokers, joker)
                end
            end

            if #jokers > 0 then
                -- Select a random joker
                local target_joker = jokers[math.random(1, #jokers)]

                -- Add visual effect
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        -- Juice up the target joker
                        target_joker:juice_up(0.8, 0.8)


                        -- Add Red 40 edition
                        target_joker:set_edition({red_40 = true}, true)

                        -- Show success message
                        card_eval_status_text(
                            target_joker,
                            'extra',
                            nil,
                            nil,
                            nil,
                            {
                                message = "FDA Approved!",
                                colour = G.C.RED,
                                delay = 0.30
                            }
                        )

                        return true
                    end
                }))
            else
                -- No valid jokers found - show failure message
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        play_sound('tarot1', 0.8, 0.4)

                        card_eval_status_text(
                            card,
                            'extra',
                            nil,
                            nil,
                            nil,
                            {
                                message = "You have no Jokers, dumbass!",
                                colour = G.C.DARK_EDITION,
                                delay = 0.45
                            }
                        )

                        return true
                    end
                }))
            end
        else
            G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.4, func = function()
                attention_text({
                    text = localize('k_nope_ex'),
                    scale = 1.3,
                    hold = 1.4,
                    major = card,
                    backdrop_colour = G.C.SECONDARY_SET.Tarot,
                    align = (G.STATE == G.STATES.TAROT_PACK or G.STATE == G.STATES.SPECTRAL_PACK) and 'tm' or 'cm',
                    offset = {x = 0, y = (G.STATE == G.STATES.TAROT_PACK or G.STATE == G.STATES.SPECTRAL_PACK) and -0.2 or 0},
                    silent = true
                    })
                    G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.06*G.SETTINGS.GAMESPEED, blockable = false, blocking = false, func = function()
                        play_sound('tarot2', 0.76, 0.4);return true end}))
                    play_sound('tarot2', 1, 0.4)
                    card:juice_up(0.3, 0.5)
            return true end }))
        end
    end,
    -- Can be used if there are jokers
    can_use = function(self, card)
        return #G.jokers.cards > 0
    end,
    -- Location text for can't use
    loc_vars = function(self, info_queue, center)
        return {vars = {}}
    end
}

SMODS.Consumable {
    key = 'the_recluse',
    set = "Spectral",
    loc_txt = {
        name = 'The Recluse',
        text = {
            '{C:attention}Doubles{} your',
            'current {C:money}money{}'
        }
    },
    atlas = 'the_recluse_atlas',
    pos = {x = 0, y = 0},
    cost = 4,
    can_use = function(self, card)
        return true
    end,
    use = function(self, card, area, copier)
        G.GAME.dollars = G.GAME.dollars * 2
        ease_dollars(give)
        return true
    end
}

-- Abnegation - Gives total sell value of all jokers and consumables
SMODS.Consumable {
    key = 'abnegation',
    set = "Spectral",
    loc_txt = {
        name = 'Abnegation',
        text = {
            'Gives the {C:money}total sell value{}',
            'of all {C:attention}Jokers{} and',
            '{C:attention}Consumables{}'
        }
    },
    atlas = 'abnegation_atlas',
    pos = {x = 1, y = 0},
    cost = 4,
    can_use = function(self, card)
        return true
    end,
    use = function(self, card, area, copier)
        local total_value = 0

        -- Calculate joker sell values
        if G.jokers then
            for i = 1, #G.jokers.cards do
                local joker = G.jokers.cards[i]
                total_value = total_value + (joker.sell_cost or 0)
            end
        end

        -- Calculate consumable sell values
        if G.consumeables then
            for i = 1, #G.consumeables.cards do
                local consumable = G.consumeables.cards[i]
                total_value = total_value + (consumable.sell_cost or 0)
            end
        end

        G.GAME.dollars = G.GAME.dollars + total_value
        ease_dollars(give)
        return true
    end
}

-- Atlas for The Recluse
SMODS.Atlas {
    key = 'the_recluse_atlas',
    path = 'fellatro_consume.png',
    px = 71,
    py = 95
}

-- Atlas for Abnegation
SMODS.Atlas {
    key = 'abnegation_atlas',
    path = 'fellatro_consume.png',
    px = 71,
    py = 95
}

SMODS.Atlas{
    key = 'fella_atlas',
    path = 'fellatro_jokers.png',
    px = 71,
    py = 95

}

SMODS.Joker {
    key = 'fella',
    loc_txt = {
        name = 'Fella',
        text = {
            'Gives {C:mult}+#1#{} Mult if',
            '{C:attention}Fellatro{} is {C:attention}installed{}',
            'and {C:attention}activated{}',
            '{C:inactive}Wait...'
        }
    },
    config = {
        extra = {
            mult = 15
        }
    },
    rarity = 1, -- Common rarity
    cost = 5,   -- Cost to buy
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    atlas = 'fella_atlas',
    pos = { x = 0, y = 4 },

    -- Calculate function - adds mult when scoring
    calculate = function(self, card, context)
        if context.joker_main then
            return {
                message = localize{type='variable',key='a_mult',vars={card.ability.extra.mult}},
                mult_mod = card.ability.extra.mult,
                colour = G.C.MULT
            }
        end
    end,

    -- Tooltip function
    loc_vars = function(self, info_queue, center)
        return {vars = {center.ability.extra.mult}}
    end
}

SMODS.Atlas({
    key = "split_joker_atlas",
    path = "fellatro_jokers.png",
    px = 71,
    py = 95
})

SMODS.Joker({
    key = "split_joker",
    loc_txt = {
        name = "Split Joker",
        text = {
            "Gives {X:chips,C:white}X#1#{} Chips and {X:mult,C:white}X#2#{} Mult",
            "if {C:attention}played hand{} has exactly",
            "{C:attention} 2 even{} and {C:attention}2 odd{} cards",
            "{C:inactive}I wonder what this is",
            "{C:inactive}a reference to..."
        }
    },
    config = {
        extra = {
            x_chips = 2,
            x_mult = 2
        }
    },
    rarity = 2, -- Uncommon rarity
    atlas = "split_joker_atlas",
    pos = {x = 5, y = 2},
    cost = 7,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,

    loc_vars = function(self, info_queue, center)
        return {
            vars = {
                center.ability.extra.x_chips,
                center.ability.extra.x_mult
            }
        }
    end,

    calculate = function(self, card, context)
        if context.joker_main then
            -- Count even and odd cards in the hand
            local even_count = 0
            local odd_count = 0

            for i = 1, #context.scoring_hand do
                local scoring_card = context.scoring_hand[i]
                local rank = scoring_card:get_id()

                -- Convert face cards to numbers (J=11, Q=12, K=13, A=14)
                local num_value = rank
                if rank == 11 then num_value = 11 -- Jack
                elseif rank == 12 then num_value = 12 -- Queen
                elseif rank == 13 then num_value = 13 -- King
                elseif rank == 14 then num_value = 1 -- Ace (treated as 1, which is odd)
                end

                -- Check if even or odd
                if num_value % 2 == 0 then
                    even_count = even_count + 1
                else
                    odd_count = odd_count + 1
                end
            end

            -- Apply bonus if exactly 2 even and 2 odd cards
            if even_count == 2 and odd_count == 2 then
                return {
                    message = localize{type='variable', key='a_xchips', vars={card.ability.extra.x_chips}} ..
                             " " .. localize{type='variable', key='a_xmult', vars={card.ability.extra.x_mult}},
                    colour = G.C.DARK_EDITION,
                    x_chips = card.ability.extra.x_chips,
                    x_mult = card.ability.extra.x_mult
                }
            end
        end
    end
})

SMODS.Atlas{
    key = 'official_deck_atlas',
    path = 'fellatro_jokers.png',
    px = 71,
    py = 95

}

SMODS.Joker {
    key = 'official_deck',
    loc_txt = {
        name = 'The Official Balatro Playing Card Deck',
        text = {
            'Gives {X:mult,C:white}X#1#{} Mult if you have',
            '{C:attention}Joker{}, {C:attention}Blueprint{}, {C:attention}Juggler{},',
            'and {C:attention}Gros Michel{}'
        }
    },
    config = { extra = { xmult = 52 } },
    rarity = 3, -- Rare rarity
    cost = 16,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = { x = 4, y = 2 },
    atlas = 'official_deck_atlas',

   loc_vars = function(self, info_queue, center)
        return { vars = { center.ability.extra.xmult } }
    end,

    calculate = function(self, card, context)
        if context.joker_main then
            -- Check if player has all required jokers
            local has_regular = false
            local has_blueprint = false
            local has_juggler = false
            local has_gros_michel = false

            -- Iterate through all jokers to check for required ones
            for i = 1, #G.jokers.cards do
                local joker = G.jokers.cards[i]
                if joker and joker.ability and joker.ability.name then
                    -- Check for Regular Joker (j_joker)
                    if joker.ability.name == "Joker" then
                        has_regular = true
                    end
                    -- Check for Blueprint (j_blueprint)
                    if joker.ability.name == "Blueprint" then
                        has_blueprint = true
                    end
                    -- Check for Juggler (j_juggler)
                    if joker.ability.name == "Juggler" then
                        has_juggler = true
                    end
                    -- Check for Gros Michel (j_gros_michel)
                    if joker.ability.name == "Gros Michel" then
                        has_gros_michel = true
                    end
                end
            end

            -- If all required jokers are present, apply the multiplier
            if has_regular and has_blueprint and has_juggler and has_gros_michel then
                return {
                    message = localize { type = 'variable', key = 'a_xmult', vars = { card.ability.extra.x_mult } },
                    xmult = card.ability.extra.xmult,
                    colour = G.C.MULT
                }
            end
        end
    end
}


SMODS.Atlas {
    key = 'worst_joker_atlas',
    path = 'fellatro_jokers.png',
    px = 71,
    py = 95
}

-- Define the joker
SMODS.Joker {
    key = 'worst_joker_ever',
    loc_txt = {
        name = 'THE WORST JOKER EVER!!!',
        text = {
            "{C:red,s:2}I HATE YOU!!!"
        }
    },
    config = {},
    rarity = 2, -- Common rarity
    pos = { x = 3, y = 2 },
    soul_pos = { x = 3, y = 3 },
    atlas = 'worst_joker_atlas',
    cost = 1,
    unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = true,

    -- This function triggers when the joker is added to your collection
    add_to_deck = function(self, card, from_debuff)
        -- Set joker slots to 0
        G.jokers.config.card_limit = 0

        -- Force remove all other jokers except this one
        for i = #G.jokers.cards, 1, -1 do
            local joker = G.jokers.cards[i]
            if joker ~= card then
                joker:remove()
            end
        end

        -- Create the four rental eternal jokers
        local jokers_to_create = {
            'j_obelisk',
            'j_matador',
            'j_seance',
            'j_8_ball'
        }

        -- Temporarily increase joker limit to add the cursed jokers
        G.jokers.config.card_limit = 5

        for _, joker_key in ipairs(jokers_to_create) do
            local new_joker = create_card('Joker', G.jokers, nil, nil, nil, nil, joker_key)

            -- Make it rental
            new_joker:set_rental(true)

            -- Make it eternal
            new_joker:set_eternal(true)

            -- Add to jokers area
            new_joker:add_to_deck()
            G.jokers:emplace(new_joker)
        end

        -- Set joker slots back to 0 after adding the cursed jokers
        G.jokers.config.card_limit = 0

        -- Show a message about what just happened
        card_eval_status_text(card, 'extra', nil, nil, nil, {
            message = "FUCK YOU!",
            colour = G.C.RED,
            delay = 1.2
        })

        return true
    end,

    -- Calculate function (even though this joker doesn't give points)
    calculate = function(self, card, context)
        -- This joker provides no benefits, only chaos
        return nil
    end
}


SMODS.Joker{
    key = 'unc_gerro',
    loc_txt = {
        name = 'Unc Gerro',
        text = {
            "Scored {C:attention}6s{} and {C:attention}7s{}",
            "give {X:mult,C:white}X#1#{} Mult"
        }
    },
    config = {extra = {xmult = 1.67}},
    rarity = 4,
    cost = 20,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 0, y = 0}, -- Adjust coordinates based on your sprite sheet
    soul_pos = {x = 0, y = 1},
    atlas = 'unc_gerro_atlas', -- Use your existing atlas name

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            if context.other_card:get_id() == 6 or context.other_card:get_id() == 7 then
                return {
                    x_mult = card.ability.extra.xmult,
                    colour = G.C.RED,
                    card = card
                }
            end
        end
    end,

    loc_vars = function(self, info_queue, center)
        return {vars = {center.ability.extra.xmult}}
    end
}

-- Create atlas for the joker sprite
SMODS.Atlas{
    key = 'unc_gerro_atlas',
    path = 'fellatro_jokers.png',
    px = 71,
    py = 95

}
-- Add localization
SMODS.current_mod.loc_txt = {
    ['en-us'] = {
        ['unc_unc_gerro'] = {
            ['name'] = 'Unc Gerro',
            ['text'] = {
                "Scored {C:attention}6s{} and {C:attention}7s{}",
                "give {X:mult,C:white}X6.7{} Mult"
            }
        }
    }
}
SMODS.Atlas {
    key = 'bar_mime_atlas',
    path = 'fellatro_jokers.png',
    px = 71,
    py = 95
}

-- Define the Bar-Mime joker
SMODS.Joker {
    key = 'bar_mime',
    loc_txt = {
        name = 'Bar-Mime',
        text = {
            "Retrigger all {C:attention}held in hand{}",
            "abilities {C:attention}2 times{}",
            "Gives {X:mult,C:white}X#1#{} Mult per {C:attention}King{} held in hand",

        }
    },
    config = {extra = {xmult = 1.75, repetitions = 2}},
    rarity = 4, -- Legendary rarity
    pos = {x = 1, y = 0},
    soul_pos = {x = 1, y = 1},
    atlas = 'bar_mime_atlas',
    cost = 20,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,

loc_vars = function(self, info_queue, center)
        local kings_in_hand = 0
        if G.hand and G.hand.cards then
            for i = 1, #G.hand.cards do
                if G.hand.cards[i]:get_id() == 13 then -- King is ID 13
                    kings_in_hand = kings_in_hand + 1
                end
            end
        end
        local current_xmult = (center.ability.extra.xmult * kings_in_hand)
        return {vars = {center.ability.extra.xmult, current_xmult}}
    end,

    -- Main joker calculation function
    calculate = function(self, card, context)
        -- Handle Xmult for Kings in hand
        if context.joker_main then
            local kings_in_hand = 0
            if G.hand and G.hand.cards then
                for i = 1, #G.hand.cards do
                    if G.hand.cards[i]:get_id() == 13 then -- King is ID 13
                        kings_in_hand = kings_in_hand + 1
                    end
                end
            end

            if kings_in_hand > 0 then
                local xmult = (card.ability.extra.xmult * kings_in_hand)
                return {
                    message = localize{type='variable',key='a_xmult',vars={xmult}},
                    Xmult_mod = xmult,
                    colour = G.C.RED
                }
            end
        end

-- Handle retriggering of held in hand card abilities
        if context.repetition and context.cardarea == G.hand then
            return {
                message = localize('k_again_ex'),
                repetitions = 2,
                card = card
            }
        end
    end
}

SMODS.Atlas {
    key = '67_kid_atlas',
    path = 'fellatro_jokers.png',
    px = 71,
    py = 95
}

SMODS.Joker {
    key = '67_kid',
    name = '6,7 Kid',
    config = {},
    pos = {x = 2, y = 0},
    soul_pos = {x = 2, y = 1},
    atlas = '67_kid_atlas',
    loc_txt = {
        name = '6,7 Kid',
        text = {
            "Shades on, I'm {C:attention}Boul Wit Da Glasses{}",
            "Bro say {C:attention}err{} 'cause he a savage",
            "So many {C:attention}dead opps{}, so many {C:attention}ashes{}",
            "You ain't catch that, I can't pass this",
            "Shooter stay strapped, I don't need mine",
            "Bro put belt right to they behind",
            "The way that {C:attention}switch brrt{}, I know he {C:attention}dyin'{}",
            "{C:attention}6-7{}, I just bipped right on the highway",
            "{C:inactive}[1 in 6.7 chance to retrigger", "{C:inactive}scored 6s and 7s 66 times]"
        }
    },
    rarity = 4,
    cost = 20,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,

    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play then
            -- Check if the card is a 6 or 7
            if context.other_card:get_id() == 6 or context.other_card:get_id() == 7 then
                -- 1/6.7 chance calculation
                if pseudorandom('67_kid') < (1/6.7) then
                    return {
                        message = localize('k_again_ex'),
                        repetitions = 66,
                        card = card
                    }
                end
            end
        end
    end
}
SMODS.Atlas{
        key = "taco_jokers",
        path = "fellatro_jokers.png",
        px = 71,
        py = 95
    }

    -- Create the Taco joker
SMODS.Joker{
        key = 'taco',
        loc_txt = {
            name = 'Taco',
            text = {
                '{C:mult}+#1#{} Mult per',
                '{C:diamonds}Diamond{} face card',
                'held in hand'
            }
        },
        config = {extra = {mult = 15}},
        rarity = 4, -- Legendary rarity
        atlas = 'taco_jokers',
        pos = {x = 3, y = 0},
        soul_pos = {x = 3, y = 1},
        cost = 20,
        unlocked = true,
        discovered = true,
        blueprint_compat = true,
        eternal_compat = true,
        perishable_compat = true,

        loc_vars = function(self, info_queue, center)
            return {vars = {center.ability.extra.mult}}
        end,

        calculate = function(self, card, context)
            if context.joker_main then
                local diamond_face_count = 0

                -- Count diamond face cards in hand
                for i = 1, #G.hand.cards do
                    local card_obj = G.hand.cards[i]
                    if card_obj.base.suit == 'Diamonds' and
                       (card_obj.base.value == 'Jack' or
                        card_obj.base.value == 'Queen' or
                        card_obj.base.value == 'King') then
                        diamond_face_count = diamond_face_count + 1
                    end
                end

                if diamond_face_count > 0 then
                    local mult_bonus = diamond_face_count * card.ability.extra.mult
                    return {
                        message = localize{type='variable',key='a_mult',vars={mult_bonus}},
                        mult_mod = mult_bonus,
                        colour = G.C.MULT
                    }
                end
            end
        end
    }
local last_processed_round = 0

-- Create the joker
SMODS.Joker{
    key = 'day15',
    loc_txt = {
        name = 'Day 15',
        text = {
            "After {C:attention}15{} rounds,",
            "retriggers {C:attention}leftmost{} and",
            "{C:attention}rightmost{} jokers {C:attention}15{} times",
            "{C:inactive}({C:attention}#1#{C:inactive} rounds remaining)",
            "{s:0.8,C:inactive,E:1}GIVE IT UP FOR DAY 15!!!"
        }
    },
    config = {
        extra = {
            rounds_remaining = 15,
            activated = false,
            start_round = 0
        }
    },
    rarity = 4, -- Legendary
    cost = 20,
    atlas = 'day15_atlas',
    pos = {x = 4, y = 0},
    soul_pos = {x = 4, y = 1},
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,

    loc_vars = function(self, info_queue, center)
        return {vars = {center.ability.extra.rounds_remaining}}
    end,

    calculate = function(self, card, context)
        -- Only update rounds at the very end of round, and only once per round
        if context.end_of_round and not context.repetition and not context.blueprint then
            -- Use G.GAME.round as the authoritative round counter
            local current_round = G.GAME.round or 1

            -- Initialize start round if this is the first time we see this card
            if card.ability.extra.start_round == 0 then
                card.ability.extra.start_round = current_round
            end

            -- Only process if we haven't already processed this round for this card
            if current_round > (card.ability.extra.last_processed_round or 0) and
               not card.ability.extra.activated then

                card.ability.extra.last_processed_round = current_round

                -- Calculate rounds played since this joker was acquired
                local rounds_played = current_round - card.ability.extra.start_round
                card.ability.extra.rounds_remaining = math.max(0, 15 - rounds_played)

                -- Check if we've reached 15 rounds
                if card.ability.extra.rounds_remaining <= 0 then
                    card.ability.extra.activated = true
                    card_eval_status_text(card, 'extra', nil, nil, nil, {message = "Give it up for day 15!", colour = G.C.RED})

                    return {
                        message = "Give it up for day 15!!",
                        colour = G.C.RED
                    }
                else
                    return {
                        message = card.ability.extra.rounds_remaining .. " days left",
                        colour = G.C.FILTER
                    }
                end
            end
        end

        -- Retrigger logic when activated
        if context.retrigger_joker_check and not context.blueprint then
            if card.ability.extra.activated then
                -- Get all jokers
                local jokers = {}
                for i = 1, #G.jokers.cards do
                    if G.jokers.cards[i] ~= card then
                        table.insert(jokers, G.jokers.cards[i])
                    end
                end

                -- Check if this is the leftmost or rightmost joker
                if #jokers > 0 then
                    local leftmost = jokers[1]
                    local rightmost = jokers[#jokers]

                    if context.other_card == leftmost or context.other_card == rightmost then
                        return {
                            message = "Again!",
                            repetitions = 15,
                            card = card
                        }
                    end
                end
            end
        end
    end
}

-- Create atlas for the joker sprite
SMODS.Atlas{
    key = 'day15_atlas',
    path = 'fellatro_jokers.png',
    px = 71,
    py = 95
}

SMODS.Atlas {
    key = "CousinGerro",
    path = "fellatro_jokers.png",
    px = 71,
    py = 95,
}

SMODS.Joker {
    key = 'cousin_gerro',
    loc_txt = {
        name = 'Cousin Gerro',
        text = {
            "Scored {C:attention}6s{} and {C:attention}7s{}",
            "give {X:chips,C:white}X#1#{} chips"
        }
    },
    config = {
        extra = {
            x_chips = 1.67
        }
    },
    rarity = 4, -- 4 = Legendary
    cost = 20,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    atlas = 'CousinGerro',
    pos = { x = 0, y = 2 },
    soul_pos = { x = 0, y = 3 },

    loc_vars = function(self, info_queue, center)
        return {vars = {center.ability.extra.x_chips}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.play and context.individual then
            -- Check if the scored card is a 6 or 7
            if context.other_card:get_id() == 6 or context.other_card:get_id() == 7 then
                return {
                    x_chips = card.ability.extra.x_chips,
                    colour = G.C.CHIPS,
                    card = card
                }
            end
        end
    end
}
SMODS.Atlas {
    key = "uncle_herro_atlas",
    path = "fellatro_jokers.png",
    px = 71,
    py = 95
}

SMODS.Joker {
    key = 'uncle_herro',
    loc_txt = {
        name = 'Uncle Herro',
        text = {
            "Scored {C:attention}6s{} and {C:attention}7s{} give",
            "{X:dark_edition,C:white}^#1#{} Mult"
        }
    },
    config = {extra = {emult = 1.67}},
    rarity = 4, -- Legendary rarity
    atlas = 'uncle_herro_atlas',
    pos = {x = 1, y = 2},
    soul_pos = {x = 1, y = 3},
    cost = 50,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,

    loc_vars = function(self, info_queue, center)
        return { vars = { number_format(center.ability.extra.emult) } }
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            -- Check if the scored card is a 6 or 7
            local rank = context.other_card:get_id()
            if rank == 6 or rank == 7 then
                return {
                    e_mult = card.ability.extra.emult,
					colour = G.C.DARK_EDITION,
					card = card
                }
            end
        end
    end
}

SMODS.Joker{
    key = 'king_george_iii',
    loc_txt = {
        name = 'King George III',
        text = {
            '{C:attention}Kings held in hand {} have',
            'a {C:green}1 in 2{} chance to create',
            'a {C:dark_edition}negative{} {C:planet}Planet{} card',
            'for your most played hand',
            '{C:attention}Scored kings{} have a',
            '{C:green}1 in 3{} chance to create',
            'a {C:dark_edition}negative{} {C:spectral}Spectral{} card'
        }
    },
    config = {},
    rarity = 4, -- Legendary rarity
    pos = {x = 2, y = 2},
    soul_pos = {x = 2, y = 3},
    atlas = 'kg3_jokers',
    cost = 20,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,

calculate = function(self, card, context)
        -- Handle kings being scored
        if context.individual and context.cardarea == G.play and context.other_card then
            if context.other_card:get_id() == 13 then -- King = 13
                if pseudorandom('kg3_spectral'..G.GAME.round_resets.ante) < (1/3) then
                    -- Create negative spectral card
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            local spectral_pool = {}
                            for k, v in pairs(G.P_CENTER_POOLS.Spectral) do
                                if v.key ~= 'c_soul' and v.key ~= 'c_black_hole' then -- Exclude problematic cards
                                    table.insert(spectral_pool, v.key)
                                end
                            end

                            if #spectral_pool > 0 and G.consumeables then
                                local spectral_key = pseudorandom_element(spectral_pool, pseudoseed('kg3_spectral_type'..G.GAME.round_resets.ante))
                                local new_card = create_card('Spectral', G.consumeables, nil, nil, nil, nil, spectral_key)
                                new_card:set_edition({negative = true}, true)
                                new_card:add_to_deck()
                                G.consumeables:emplace(new_card)

                                card_eval_status_text(card, 'extra', nil, nil, nil, {
                                    message = "Negative Spectral!",
                                    colour = G.C.DARK_EDITION
                                })
                            end
                            return true
                        end
                    }))


                end
            end
        end

        -- Handle end of round for kings in hand
        if context.end_of_round and not context.individual and not context.repetition then
            local kings_in_hand = 0
            for i = 1, #G.hand.cards do
                if G.hand.cards[i]:get_id() == 13 then -- King = 13
                    kings_in_hand = kings_in_hand + 1
                end
            end

            if kings_in_hand > 0 then
                G.E_MANAGER:add_event(Event({
                    func = function()
                        -- For each king in hand, 1 in 2 chance to create negative planet
                        for i = 1, kings_in_hand do
                            if pseudorandom('kg3_planet'..G.GAME.round_resets.ante..i) < 0.5 then
                                -- Get most played hand
                                local most_played_hand = nil
                                local highest_count = 0
                                for k, v in pairs(G.GAME.hands) do
                                    if v.played > highest_count then
                                        highest_count = v.played
                                        most_played_hand = k
                                    end
                                end

                                if most_played_hand and G.consumeables then
                                    -- Create negative planet card
                                    local planet_key = nil
                                    for k, v in pairs(G.P_CENTER_POOLS.Planet) do
                                        if v.config and v.config.hand_type == most_played_hand then
                                            planet_key = v.key
                                            break
                                        end
                                    end

                                    if planet_key then
                                        local new_card = create_card('Planet', G.consumeables, nil, nil, nil, nil, planet_key)
                                        new_card:set_edition({negative = true}, true)
                                        new_card:add_to_deck()
                                        G.consumeables:emplace(new_card)

                                        card_eval_status_text(card, 'extra', nil, nil, nil, {
                                            message = "Negative Planet!",
                                            colour = G.C.DARK_EDITION
                                        })
                                    end
                                end
                            end
                        end
                        return true
                    end
                }))


            end
        end
    end
}
-- Register the atlas for the joker sprite
SMODS.Atlas{
    key = 'kg3_jokers',
    path = 'fellatro_jokers.png',
    px = 71,
    py = 95
}

SMODS.Atlas({
    key = "phantom_atlas",
    path = "fellatro_jokers.png",
    px = 71,
    py = 96
})

SMODS.Joker({
    key = "the_phantom",
    loc_txt = {
        name = "The Phantom",
        text = {
            "Retrigger all {C:attention}Jokers{}",
            "{C:attention}once{} for each {C:spectral}Spectral{}",
            "card used this run",
            "{C:inactive}(Currently {C:attention}#1#{C:inactive} retriggers)"
        }
    },
    config = {
        extra = {
            spectral_count = 0,
            retriggers = 0
        }
    },
    rarity = 4,
    pos = { x = 5, y = 0 },
    soul_pos = { x = 5, y = 1 },
    atlas = "phantom_atlas",
    cost = 50,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = false,

    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.retriggers or 0 } }
    end,

    calculate = function(self, card, context)
        -- Track spectral cards used
        if context.using_consumeable and context.consumeable and context.consumeable.ability.set == 'Spectral' then
            card.ability.extra.spectral_count = card.ability.extra.spectral_count
            card.ability.extra.retriggers = card.ability.extra.spectral_count

            -- Update card description
            card_eval_status_text(card, 'extra', nil, nil, nil, {
                message = "Energized!",
                colour = G.C.SPECTRAL
            })
        end

        -- Retrigger all jokers during joker calculation
        if context.retrigger_joker_check and not context.retrigger_joker and context.other_card ~= card then
            return {
                message = localize('k_again_ex'),
                repetitions = card.ability.extra.retriggers,
                card = card
            }
        end
    end,

    -- Reset spectral count when starting new run
    add_to_deck = function(self, card, from_debuff)
        card.ability.extra.spectral_count = G.GAME.spectral_used_this_run or 0
        card.ability.extra.retriggers = card.ability.extra.spectral_count
    end,

    -- Save spectral count in game state
    set_ability = function(self, card, initial, delay_sprites)
        card.ability.extra.spectral_count = card.ability.extra.spectral_count or 0
        card.ability.extra.retriggers = card.ability.extra.spectral_count
    end
}

      )
local use_consumeable_ref = Card.use_consumeable
function Card:use_consumeable(area, copier)
    if self.ability.set == 'Spectral' then
        G.GAME.spectral_used_this_run = (G.GAME.spectral_used_this_run or 0) + 1

        -- Update all Phantom jokers
        for i = 1, #G.jokers.cards do
            if G.jokers.cards[i].ability.name == 'j_the_phantom' then
                G.jokers.cards[i].ability.extra.spectral_count = G.GAME.spectral_used_this_run
                G.jokers.cards[i].ability.extra.retriggers = G.GAME.spectral_used_this_run
            end
        end
    end

    return use_consumeable_ref(self, area, copier)
end

-- Initialize spectral counter for new runs
local new_round_ref = Game.start_run
function Game:start_run(args)
    G.GAME.spectral_used_this_run = 0
    return new_round_ref(self, args)
end

end

----------------------------------------------
------------MOD CODE END----------------------
